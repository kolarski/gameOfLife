### Welcome.

To run the test you just have to:

```bash
$ php phpunit.php GameOfLifeTest.php
```

If you like you could use some colors in your output

```bash
$ php phpunit.php --colors GameOfLifeTest.php
```

And for more info about PHPUnit command line tool:

```bash
$ php phpunit.php --help
```

To write the code you could use `GameOfLife.php`. Just if you want to.

Have fun ...
