        "panel{line}": {
          "header": "{header}",
          "body": "<ul>{tests}</ul>",
          "footer": ""
        },
