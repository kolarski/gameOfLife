<?php

/**
 * Class: Game of life
 * 
 * 
 */

class GameOfLife
{
  function __construct()
  {
    echo 'hello world';
  }

}
$GameOfLife = new GameOfLife();
?>
