<?php

/**
 * Class: GameOfLife 
 * Extends: PHPUnit_Framework_TestCase
 *
 */

class GameOfLifeTest extends PHPUnit_Framework_TestCase
{

    /*
     * SetUp Test cases
     *
     */
    public function setUp()
    {
      require_once('./GameOfLife.php');
    }

    /*
     * Test: Test if class Game of life exists. (dummy test)
     */
    public function testGameOfLifeClass()
    {
        $this->assertEquals(class_exists('GameOfLife'), true);
    }
}
