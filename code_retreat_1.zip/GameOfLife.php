<?php

/**
 * Class: Game of life
 * 
 * 
 */

class GameOfLife
{
    public $board;
    public $size;
    function __construct()
    {
       $this->createBoard();
    }

    private function createBoard()
    {
         $this->board = array();
         $this->size = 10;
         for ($i=0; $i<= $this->size; $i++)
         {
            for($j=0; $j<= $this->size; $j++)
            {
                $this->board[$i][$j] = 0;
            }
         }
    }

    public function createPoint($point = 0)
    {
        $this->board[$point[0]][$point[1]] = 1;
    }

    public function deletePoint($point = 0)
    {
        $this->board[$point[0]][$point[1]] = 0;
    }

    public function getNeighbours($point = array())
    {
        $neighbours_count = 0;
        $neightbours = array(
            array($point[0], $point[1]-1),
            array($point[0], $point[1]+1),
            array($point[0]-1, $point[1]),
            array($point[0]-1, $point[1]-1),
            array($point[0]-1, $point[1]+1),
            array($point[0]+1, $point[1]),
            array($point[0]+1, $point[1]-1),
            array($point[0]+1, $point[1]+1)
        );
        foreach ($neightbours as $neightbour)
        {
            var_dump($neightbour[0]][$neightbour[1]);
            if($this->cellExists($neightbour) && $this->board[$neightbour[0]][$neightbour[1]] == 1)
            {
                $neighbours_count += 1;
            }
        }
    }
    public function cellExists($point = array())
    {
        if($point[0] < 0 || $point[0] > $this->size || $point[1] < 0 || $point[1] > $this->size )
        {
            return false;
        }
        else
        {
            return true;
        }
    }



}

?>
