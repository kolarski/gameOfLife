<?php

/**
 * Class: GameOfLife 
 * Extends: PHPUnit_Framework_TestCase
 *
 */

class GameOfLifeTest extends PHPUnit_Framework_TestCase
{

    /*
     * SetUp Test cases
     *
     */
    public function setUp()
    {
      require_once('./GameOfLife.php');
      $this->GameOfLife = new GameOfLife();
    }

    /*
     * Test: Test if class Game of life exists. (dummy test)
     */
    public function testGameOfLifeClass()
    {
        $this->assertEquals(class_exists('GameOfLife'), true);
    }

    public function testBoardExists()
    {
        $this->assertEquals(isset($this->GameOfLife->board), true);
    }

    public function testCreateBoardMethodExists()
    {
        $this->assertEquals(method_exists($this->GameOfLife, 'createBoard'), true);
    }

    public function testBoardSize()
    {
        $size = $this->GameOfLife->size;
        for ($i=0; $i<= $size; $i++)
        {
            for($j=0; $j<= $size; $j++)
            {
                $this->assertEquals($this->GameOfLife->board[$i][$j], 0);
            }
         }        
    }

    public function testCreatePointExists()
    {
         $this->assertEquals(method_exists($this->GameOfLife, 'CreatePoint'), true);
    }

    public function testCreatePoint()
    {
        $size = $this->GameOfLife->size;
        $i = rand(0, $size-1);
        $j = rand(0, $size-1);

        $this->assertEquals($this->GameOfLife->board[$i][$j], 0);
        
        $this->GameOfLife->CreatePoint(array($i, $j));
        
        $this->assertEquals($this->GameOfLife->board[$i][$j], 1);
    }

    public function testDeletePointExists()
    {
         $this->assertEquals(method_exists($this->GameOfLife, 'deletePoint'), true);
    }

    public function testDeletePoint()
    {
        $size = $this->GameOfLife->size;
        $i = rand(0, $size-1);
        $j = rand(0, $size-1);

        $this->GameOfLife->CreatePoint(array($i, $j));

        $this->assertEquals($this->GameOfLife->board[$i][$j], 1);
        
        $this->GameOfLife->deletePoint(array($i, $j));
        
        $this->assertEquals($this->GameOfLife->board[$i][$j], 0);
    }

    public function testGetNeighboursExists()
    {
        $this->assertEquals(method_exists($this->GameOfLife, 'getNeighbours'), true);
    }

    public function testGetNeighbours()
    {
        $i = 5;
        $j = 0;
        $this->GameOfLife->createPoint(array(4,2));
        $this->GameOfLife->createPoint(array(6,2));
        $this->GameOfLife->getNeighbours(array($i, $j));

        $this->assertEquals($this->GameOfLife->getNeighbours(), 2);
    }

    public function testCellExistsExists()
    {
        $this->assertEquals(method_exists($this->GameOfLife, 'cellExists'), true);
    }

    public function testCellExists()
    {
        $point = array(-1, 5);
        $this->assertEquals($this->GameOfLife->cellExists($point), false,  "5");

        $point = array(-1, -1);
        $this->assertEquals($this->GameOfLife->cellExists($point), false, "4");

        $point = array(0, 0);
        $this->assertEquals($this->GameOfLife->cellExists($point), true, "3");

        $point = array($this->GameOfLife->size, $this->GameOfLife->size);
        $this->assertEquals($this->GameOfLife->cellExists($point), true, "2");

        $point = array($this->GameOfLife->size+1, $this->GameOfLife->size+1);
        $this->assertEquals($this->GameOfLife->cellExists($point), false, "1");
    }


}
