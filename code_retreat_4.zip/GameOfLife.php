<?php

/**
 * Class: Game of life
 * 
 * 
 */

class Board
{
    public $board_size;
    public $board;
    function __construct($board_size)
    {
        $this->board_size = $board_size;
        $this->_initBoard();
    }
    private function _initBoard()
    {
       $this->board = str_pad('', $this->board_size[0] * $this->board_size[1], '0');
    }
    public function getPoint($point)
    {
        return $this->board[$this->board_size[0] * $point[0] + $point[1]];
    }
    public function setPoint($point, $value)
    {
        $this->board[$this->board_size[0]*$point[0] + $point[1]] = $value;
    }
    public function getBoardSize()
    {
        return $this->board_size;
    }
}


class GameOfLife
{
    public $board;
    function __construct()
    {

    }
    public function getBoard()
    {   
        return $this->board;
    }
    public function setBoard(Board $board)
    {
        $this->board = $board;
    }
    public function countBoardLiveCells()
    {
        $board = $this->board->board;
        return strlen($board) - strlen(str_replace('1', '', $board));
    }
}
?>
