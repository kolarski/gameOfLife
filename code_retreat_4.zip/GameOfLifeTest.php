<?php

/**
 * Class: GameOfLife 
 * Extends: PHPUnit_Framework_TestCase
 *
 */

class GameOfLifeTest extends PHPUnit_Framework_TestCase
{

    /*
     * SetUp Test cases
     *
     */
    public function setUp()
    {
        $board_size = array(10,10);

        require_once('./GameOfLife.php');
        $this->GameOfLife = new GameOfLife();
        $this->Board = new Board($board_size);
    }

    /*
     * Test: Test if class Game of life exists. (dummy test)
     */
    public function testClassExistance()
    {
        $this->GameOfLife->setBoard($this->Board);
        $this->assertEquals($this->GameOfLife->getBoard(), $this->Board);
    }

    public function testBoardExists()
    {
        $this->assertEquals(strlen($this->Board->board) === 100, true, 'Board length !== 100');
    }

    public function testBoardHasLiveCells()
    {
        $this->Board->setPoint(array(5,5), 1);
        $this->GameOfLife->setBoard($this->Board);

        $this->assertEquals($this->GameOfLife->countBoardLiveCells() > 0, true, 'No live cells');
    }

    public function testBoardNeighbours()
    {
        $this->assertEquals($this->Board->getNeighbours(array(2,3)) > 0, true, 'No neighbours');
    }
}
