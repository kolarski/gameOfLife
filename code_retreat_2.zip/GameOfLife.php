<?php

/**
 * Class: Game of life
 * 
 * 
 */

class GameOfLife
{
    public $size;
    public $board = array();
    public $new_board = array();
    
    function __construct()
    {

    }
    public function createBoard($size)
    {
        $this->size = $size;

        for($i=0; $i<=$this->size; $i++)
        {
            for($j=0; $j<=$this->size; $j++)
            {
                $this->board[$i][$j] = 0;
                $this->new_board[$i][$j] = 0;
            }
        }
    }

    public function createDot($dot = array())
    {
        $this->board[$dot[0]][$dot[1]] = 1;
    }

    public function removeDot($dot = array())
    {
        $this->board[$dot[0]][$dot[1]] = 0;
    }

    public function cellExists($point = array())
    {
        if($point[0] < 0 || $point[0] > $this->size || $point[1] < 0 || $point[1] > $this->size)
        {
            return false;
        }
        return true;
    }

    public function getNeighboursCount($dot)
    {
        $count = 0;
        $neighbours = array(
            array($dot[0], $dot[1]+1),
            array($dot[0], $dot[1]-1),
            array($dot[0]+1, $dot[1]),
            array($dot[0]+1, $dot[1]+1),
            array($dot[0]+1, $dot[1]-1),
            array($dot[0]-1, $dot[1]),
            array($dot[0]-1, $dot[1]+1),
            array($dot[0]-1, $dot[1]-1)
        );

        foreach ($neighbours as $neighbour)
        {
            if($this->cellExists($neighbour) && $this->board[$neighbour[0]][$neighbour[1]] == 1)
            {
                $count += 1;
            }
        }
        return $count;
    }

    public function cellNextGen($point)
    {
        $count = $this->getNeighboursCount($point);
        if ($this->board[$point[0]][$point[1]] == 0)
        {
            /* dead cell */
             if ($count == 3)
             {
                $this->new_board[$point[0]][$point[1]] = 1;
             }
        }
        else
        {
            if ($count < 2)
            {
                $this->new_board[$point[0]][$point[1]] = 1;
            }
            if ($count == 2 && $count == 3)
            {
                $this->new_board[$point[0]][$point[1]] = 1;
            }
            if ($count < 2)
            {
                $this->new_board[$point[0]][$point[1]] = 1;
            }
            /* living cell */
        }
       
        $this->board = $this->new_board;

    }

}

?>
