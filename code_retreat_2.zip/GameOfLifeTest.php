<?php

/**
 * Class: GameOfLife 
 * Extends: PHPUnit_Framework_TestCase
 *
 */

class GameOfLifeTest extends PHPUnit_Framework_TestCase
{

    /*
     * SetUp Test cases
     *
     */
    public function setUp()
    {
      require_once('./GameOfLife.php');
      $this->GameOfLife = new GameOfLife();
      $this->GameOfLife->createBoard(50);
    }

    /*
     * Test: Test if class Game of life exists. (dummy test)
     */
    public function testGameOfLifeClass()
    {
        $this->assertEquals(class_exists('GameOfLife'), true);
    }

    public function testCreateBoardExists()
    {
        $this->assertEquals(method_exists($this->GameOfLife, 'createBoard'), true);
    }

    public function testCreateBoard()
    {
        $this->GameOfLife->createBoard(50);
        for($i=0; $i<=$this->GameOfLife->size; $i++)
        {
            for($j=0; $j<=$this->GameOfLife->size; $j++)
            {
                $this->assertEquals(isset($this->GameOfLife->board[$i][$j]), true);
                $this->assertEquals($this->GameOfLife->board[$i][$j], 0);
            }
        }
    }

    public function testCreateDot($value='')
    {
        $i = rand(0, count($this->GameOfLife->size));
        $j = rand(0, count($this->GameOfLife->size));

        $this->assertEquals($this->GameOfLife->board[$i][$j], 0);
        $this->GameOfLife->createDot(array($i, $j));
        $this->assertEquals($this->GameOfLife->board[$i][$j], 1);
    }

    public function testRemoveDot($value='')
    {
        $i = rand(0, count($this->GameOfLife->size));
        $j = rand(0, count($this->GameOfLife->size));

        $this->GameOfLife->createDot(array($i, $j));
        $this->assertEquals($this->GameOfLife->board[$i][$j], 1);
        $this->GameOfLife->removeDot(array($i, $j));
        $this->assertEquals($this->GameOfLife->board[$i][$j], 0);
    }

    public function testCellExists()
    {
        $points = array(
            array(
                'point'     => array(-1,-1),
                'result'    => false
            ),
            array(
                'point'     => array(-1,0),
                'result'    => false
            ),
            array(
                'point'     => array(0,-1),
                'result'    => false
            ),
            array(
                'point'     => array(0,0),
                'result'    => true
            ),
            array(
                'point'     => array($this->GameOfLife->size,$this->GameOfLife->size),
                'result'    => true
            ),
            array(
                'point'     => array($this->GameOfLife->size+1,$this->GameOfLife->size+1),
                'result'    => false
            ),
            array(
                'point'     => array(15,15),
                'result'    => true
            ),
        );

        foreach ($points as $test)
        {
            $this->assertEquals($this->GameOfLife->cellExists($test['point']), $test['result']);
        }
    }

    public function testGetNeighboursCount()
    {
        $point = array(0,0);
        $this->GameOfLife->createDot(array(0,0));
        $this->assertEquals($this->GameOfLife->getNeighboursCount($point), 0);

        $this->GameOfLife->createDot(array(1,1));
        $this->assertEquals($this->GameOfLife->getNeighboursCount($point), 1);

        $this->GameOfLife->createDot(array(1,0));
        $this->assertEquals($this->GameOfLife->getNeighboursCount($point), 2);

        $this->GameOfLife->createDot(array(0,1));
        $this->assertEquals($this->GameOfLife->getNeighboursCount($point), 3);

        $this->GameOfLife->createDot(array(2,2));
        $this->assertEquals($this->GameOfLife->getNeighboursCount($point), 3);

        $this->GameOfLife->removeDot(array(1,0));
        $this->assertEquals($this->GameOfLife->getNeighboursCount($point), 2);

        $this->GameOfLife->removeDot(array(1,1));
        $this->GameOfLife->removeDot(array(0,1));
        $this->assertEquals($this->GameOfLife->getNeighboursCount($point), 0);
    }

    public function testCellNextGen()
    {
        $this->GameOfLife->createBoard(50);
        $point = array(0,0);
        $this->GameOfLife->createDot($point);
        $this->GameOfLife->createDot(array(0,1));
        $this->GameOfLife->cellNextGen($point);
        $this->assertEquals($this->GameOfLife->new_board[$point[0]][$point[1]], 0);


    }
}
