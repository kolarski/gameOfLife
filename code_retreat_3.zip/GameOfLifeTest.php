<?php

/**
 * Class: GameOfLife 
 * Extends: PHPUnit_Framework_TestCase
 *
 */

class GameOfLifeTest extends PHPUnit_Framework_TestCase
{
    public $GameOfLife;
    /*
     * SetUp Test cases
     *
     */
    public function setUp()
    {
      require_once('./GameOfLife.php');
      $this->GameOfLife = new GameOfLife();
    }

    /*
     * Test: Test if class Game of life exists. (dummy test)
     */
    public function testGameOfLifeClass()
    {
        $this->assertEquals(class_exists('GameOfLife'), true);
    }
    
    public function testCreateBoard()
    {
        /* Here we have a board =) with error :)*/
        $this->assertEquals($this->GameOfLife->createBoard(50), true);
    }

    /**
     * Test adding a Point to board
     * 
     */
    public function testAddPoint()
    {
        $point = array(5,5);
        $this->assertEquals(method_exists($this->GameOfLife, 'addPoint'), true);
        $this->assertEquals($this->GameOfLife->board[5][5], 0);
        $this->GameOfLife->addPoint($point);
        $this->assertEquals($this->GameOfLife->board[5][5], 1);
    }

    public function testRemovePoint()
    {
        $point = array(5,5);
        $this->assertEquals(method_exists($this->GameOfLife, 'removePoint'), true, "The method does not exists");
        $this->GameOfLife->addPoint($point);
        $this->assertEquals($this->GameOfLife->board[5][5], 1, "The point is NOT empty");
        $this->GameOfLife->removePoint($point);
        $this->assertEquals($this->GameOfLife->board[5][5], 0, "The point is empty =)");
    }

    public function testPointExists()
    {
        $point = array(-1, -1);
        $this->assertEquals(method_exists($this->GameOfLife, 'pointExists'), true, "The method does not exists");
        $this->assertEquals($this->GameOfLife->pointExists($point), false, "The point does not exists");

        $point = array(0,0);
        $this->assertEquals($this->GameOfLife->pointExists($point), true, "The point (0,0) exists");
    }

    public function testGetPointNeighbors()
    {

        $this->GameOfLife->createBoard(50);

        $point = array(5,5);
        $this->GameOfLife->addPoint($point);
        $this->assertEquals($this->GameOfLife->getPointNeighbors($point), 0, "the point has no neighbors");

        $point = array(5,4);
        $this->GameOfLife->addPoint($point);
        $this->assertEquals($this->GameOfLife->getPointNeighbors(array(5,5)), 1, "The point has one neighbor now =) ");
    }

    public function testSetPointNextState()
    {
        /* OK li e do tuk :) extra */
        
        $point = array(0,0);
        $this->GameOfLife->createBoard(50);
        $this->GameOfLife->addPoint($point);
        
        $this->GameOfLife->addPoint(array(0,1));
        $this->GameOfLife->setNextPointState($point);
        $this->assertEquals($this->GameOfLife->new_board[0][0], 0);

        $this->GameOfLife->addPoint(array(1,1));
        $this->GameOfLife->setNextPointState($point);
        $this->assertEquals($this->GameOfLife->new_board[0][0], 1);

        $this->GameOfLife->addPoint(array(1,0));
        $this->GameOfLife->setNextPointState($point);
        $this->assertEquals($this->GameOfLife->new_board[0][0], 1);

        $this->GameOfLife->removePoint(array(0,0));
        $this->GameOfLife->setNextPointState($point);
        $this->assertEquals($this->GameOfLife->new_board[0][0], 0);

    }

    /**
     * testNextIteration
     * 
     */
    public function testNextIteration()
    {
        $point = array(0,0);
        $this->GameOfLife->createBoard(50);

        $this->GameOfLife->addPoint(array(1,0));
        $this->GameOfLife->addPoint(array(1,1));
        $this->GameOfLife->addPoint(array(0,1));
        
        $this->GameOfLife->nextIteration();

        $this->assertEquals($this->GameOfLife->board[0][1], 0);
        $this->assertEquals($this->GameOfLife->board[1][1], 0);
        $this->assertEquals($this->GameOfLife->board[1][0], 0);
        $this->assertEquals($this->GameOfLife->board[0][0], 1);
    }
}
