<?php

/**
 * Class: Game of life
 * 
 * 
 */

class GameOfLife
{
    public $board, $size, $new_board;
  function __construct()
  {
    
  }
  public function createBoard($size)
  {
    $this->size = $size;
      for($i=0; $i<=$this->size; $i++)
      {
        for($j=0; $j<=$this->size; $j++)
        {
            $this->board[$i][$j] = 0;
            $this->new_board[$i][$j] = 0;
        }
      }
      return true;
  }
  public function addPoint($point = array())
  {
    $this->board[$point[0]][$point[1]] = 1;
  }
  public function removePoint($point)
  {
      $this->board[$point[0]][$point[1]] = 0;
  }

  public function pointExists($point)
  {
      if($point[0] < 0 || $point[0] > $this->size || $point[1] < 0 || $point[1] > $this->size)
      {
        return false;
      } else {
        return true;
      }
  }
  public function getPointNeighbors($point)
  {
        $count = 0;
        $neighbors = array(
            array($point[0], $point[1]-1),
            array($point[0], $point[1]+1),
            array($point[0]+1, $point[1]),
            array($point[0]+1, $point[1]+1),
            array($point[0]+1, $point[1]-1),
            array($point[0]-1, $point[1]),
            array($point[0]-1, $point[1]+1),
            array($point[0]-1, $point[1]-1)

        );
        foreach ($neighbors as $neighbor)
        {
            if($this->pointExists($neighbor) && $this->board[$neighbor[0]][$neighbor[1]] == 1)
            {

                $count += 1;
            }
        }
      return $count;
  }

  public function setNextPointState($point)
  {
    if($this->board[$point[0]][$point[1]] == 1)
    {
        /* The point is alive */
        $count = $this->getPointNeighbors($point);
        if($count < 2 || $count > 3)
        {
            $this->new_board[$point[0]][$point[1]] = 0;
        } else if ($count == 2 || $count == 3)
        {
            $this->new_board[$point[0]][$point[1]] = 1;
        }

    }
    else 
    {
        /* The point is dead ;( */
        if ($this->getPointNeighbors($point) == 3)
        {
            $this->new_board[$point[0]][$point[1]] = 0;
        }
    }

  }

  public function nextIteration()
  {
      for ($i=0; $i < $this->size; $i++)
      { 
        for ($j=0; $j < $this->size; $j++)
        {
            $this->setNextPointState(array($i, $j));
        }
      }
      $this->board = $this->new_board;
  }

}
?>
